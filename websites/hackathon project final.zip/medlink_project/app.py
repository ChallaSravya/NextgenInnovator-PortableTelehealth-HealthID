from flask import Flask, render_template, request, redirect, session
import sqlite3, uuid, qrcode
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "medlink_secret"

# ---------- DATABASE ----------
def init_db():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    # Users table with UNIQUE username
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        username TEXT UNIQUE,
        password TEXT,
        role TEXT)''')

    # Patients table
    c.execute('''CREATE TABLE IF NOT EXISTS patients (
        id TEXT PRIMARY KEY,
        name TEXT,
        age INTEGER,
        records TEXT)''')

    conn.commit()
    conn.close()

init_db()

# ---------- HOME ----------
@app.route('/')
def home():
    return render_template('home.html')

# ---------- LOGIN ----------
@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=?", (username,))
        user = c.fetchone()
        conn.close()

        if user and check_password_hash(user[1], password):
            session['user'] = username
            session['role'] = user[2]
            if user[2] == "doctor":
                return redirect('/dashboard')
            else:
                return redirect('/patient_dashboard')
        else:
            return "Invalid credentials or user does not exist!"

    return render_template('login.html')

# ---------- REGISTER CHOICE ----------
@app.route('/choose_register')
def choose_register():
    return render_template('choose_register.html')

# ---------- REGISTER DOCTOR ----------
@app.route('/register_doctor', methods=['GET','POST'])
def register_doctor():
    if request.method == 'POST':
        username = request.form['username']
        password = generate_password_hash(request.form['password'])

        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        # Check for duplicate username
        c.execute("SELECT * FROM users WHERE username=?", (username,))
        if c.fetchone():
            conn.close()
            return "Username already exists! Please choose another."

        c.execute("INSERT INTO users VALUES (?,?,?)",
                  (username, password, "doctor"))
        conn.commit()
        conn.close()
        return redirect('/login')

    return render_template('register_doctor.html')

# ---------- REGISTER PATIENT ----------
@app.route('/register_patient', methods=['GET','POST'])
def register_patient():
    if request.method == 'POST':
        name = request.form['name']
        age = request.form['age']
        username = request.form['username']
        password = generate_password_hash(request.form['password'])

        conn = sqlite3.connect('database.db')
        c = conn.cursor()

        # Check if username already exists
        c.execute("SELECT * FROM users WHERE username=?", (username,))
        if c.fetchone():
            conn.close()
            return "Username already exists! Please choose another."

        # Check if patient with same name+age exists
        c.execute("SELECT * FROM patients WHERE name=? AND age=?", (name, age))
        if c.fetchone():
            conn.close()
            return "Patient already registered with same name and age!"

        patient_id = str(uuid.uuid4())

        # Insert into patients
        c.execute("INSERT INTO patients VALUES (?,?,?,?)",
                  (patient_id, name, age, ""))

        # Insert into users
        c.execute("INSERT INTO users VALUES (?,?,?)",
                  (username, password, "patient"))

        conn.commit()
        conn.close()

        # Generate QR code with patient URL
        url = f"http://127.0.0.1:5000/patient/{patient_id}"
        img = qrcode.make(url)
        img.save(f"static/{patient_id}.png")

        return render_template('success.html', pid=patient_id)

    return render_template('register_patient.html')

# ---------- DOCTOR DASHBOARD ----------
@app.route('/dashboard')
def dashboard():
    if 'user' not in session or session['role'] != 'doctor':
        return redirect('/login')
    return render_template('dashboard.html')

# ---------- PATIENT DASHBOARD ----------
@app.route('/patient_dashboard')
def patient_dashboard():
    if 'user' not in session or session['role'] != 'patient':
        return redirect('/login')
    return render_template('patient_dashboard.html')

# ---------- VIEW & UPDATE PATIENT ----------
@app.route('/patient/<id>', methods=['GET','POST'])
def view_patient(id):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    if request.method == 'POST':
        record = request.form['record']
        c.execute("UPDATE patients SET records=? WHERE id=?", (record, id))
        conn.commit()

    c.execute("SELECT * FROM patients WHERE id=?", (id,))
    p = c.fetchone()
    conn.close()

    return render_template('patient_view.html', p=p)

# ---------- LOGOUT ----------
@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

if __name__ == "__main__":
    app.run(debug=True)